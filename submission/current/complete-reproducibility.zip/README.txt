Sharp Hypergeometric Concentration: Exact Exchangeability Constants, Fixed-Sample Extremizers, and Piecewise KL Bounds
Zinan Wang: The University of Manchester
Xinhao Yang: University of Southern California

To build the Lean proof project from a clean directory:
  lake exe cache get
  lake build ExactHoeffding
  python3 checks/generate_axiom_audit.py --check
  lake env lean checks/full_closure_axioms.lean

To reproduce numerical checks:
  python3 -m pip install -r requirements.txt
  python3 checks/verify_piecewise_kl.py
  python3 goal_b/code/verify_goal_b.py --maxN 60 --numericN 18 --output goal_b/checks/verification.json

To rebuild the paper:
  python3 submission/integrated/build_clean_submission.py
  (cd submission/integrated && latexmk -pdf -halt-on-error combined_manuscript.tex)

All formal statements are checked by the pinned Lean kernel and the generated audit.

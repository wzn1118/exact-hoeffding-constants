Sharp Hypergeometric Concentration: Exact Exchangeability Constants, Fixed-Sample Extremizers, and Piecewise KL Bounds
Zinan Wang — The University of Manchester
Xinhao Yang — University of Southern California

This is the current Main+A+B paper and verification package. Earlier Main-only papers, supplements, release ZIPs, and their validation scripts are historical records, not the entry point for this manuscript.

Requirements:
  Python 3.11+, Git, network access for the pinned Mathlib cache, Lean 4 from lean-toolchain,
  TeX Live/pdfLaTeX, latexmk, and Poppler pdfinfo.

Install elan and both Python dependency sets (Linux):
  curl -sSfL https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh | sh -s -- -y --default-toolchain none
  export PATH="$HOME/.elan/bin:$PATH"
  python3 -m pip install -r requirements.txt
  python3 -m pip install -r goal_b/requirements.txt

From the extracted archive root, run the complete verification:
  bash checks/verify_current_reproducibility.sh

The script checks archive checksums, all 240 current-source display bindings, theorem correspondence,
numerical checks, the Lean build and axiom audit, and a clean 37-page manuscript build.
The commands do not require Git history or workspace-specific paths. Mathlib cache retrieval needs network access.

AI-assisted tools were used in Lean 4 formalization and verification.

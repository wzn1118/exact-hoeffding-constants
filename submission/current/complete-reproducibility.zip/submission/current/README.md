# Current manuscript included in this reproduction archive

Sharp Hypergeometric Concentration: Exact Exchangeability Constants, Fixed-Sample Extremizers, and Piecewise KL Bounds

These are the official Main+A+B manuscript and verification inputs.

- Paper PDF: `manuscript.pdf` (this directory)
- LaTeX source: `manuscript.tex` (this directory)
- Theorem–Lean concordance: `theorem_lean_concordance.md`
- Theorem manifest: `theorem_lean_manifest.json`
- Display inventory and review bindings: `display_formula_inventory.json`, `display_formula_review_bindings.json`
- Reproduction instructions: archive-root `README.txt`

The arXiv-source and clean-submission ZIPs are published beside the full archive in the repository's `submission/current/`; they are not nested in this archive.

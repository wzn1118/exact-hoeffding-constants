# Exact Hoeffding Constants for Finite Exchangeable Sequences

Zinan Wang · 2026-10-15

This research bundle contains the complete article, its modular LaTeX source, all project Lean source, pinned toolchain and dependency metadata, reproduction scripts, theorem mapping, source and audit records, and the cited literature catalogue.

## Article

Read `article/combined_all.pdf`. The source `article/combined_all.tex` contains the principal paper and all technical refinements with one bibliography. The separate principal paper and supplement are `manuscript.pdf` and `supplementary_refinements.pdf`. Run `bash build_articles.sh` to rebuild the three PDFs.

For arXiv, use `Wang_Zinan_Exact_Hoeffding_arXiv_Source_2026-10-15.zip`. The abstract and metadata are provided separately.

## Lean reproduction

Install elan, Python 3 and Git, then run `bash reproduce_formal.sh`. The `lean-toolchain` file selects Lean 4.33.0. `lake-manifest.json` pins Mathlib and all its dependencies; `lake exe cache get` downloads their sources and compiled cache. No compiled project objects are included. The source is checked by `lake build ExactHoeffding`, the umbrella is checked independently, and the generated public-theorem audit is compared and checked against its complete transitive axiom dependencies.

Mathlib commit: `db584cd6d46c92f209a44c0f1c829460d327499d`. The included snapshot has 253 project Lean source files and an umbrella audit listing 1518 public theorems in 252 project modules. `RESEARCH_PROVENANCE.json` records the exact source snapshot and its consistency checks.

The theorem-to-manuscript mapping, mathematical hypotheses and verification scope are recorded in `theorem_to_lean.csv`, `README_LEAN4.md`, `LEAN_PROOF_STATUS.md`, `proof_gap_register.md` and `formal_status/`. The retained build records are in `checks/logs/full_closure/`; the reproduction script writes fresh results to `build/formal/`.

## Literature and rights

`refs/` identifies all 16 cited works and includes four unchanged CC BY 4.0 PDFs, each with a recorded source, license and SHA-256 checksum. `THIRD_PARTY_NOTICES.md` preserves their attribution.

Copyright (c) 2026 Zinan Wang. All rights reserved in the original work. See `LICENSE` and `COPYRIGHT.md`.

Verify the delivered inventory with `sha256sum -c SHA256SUMS.txt`.

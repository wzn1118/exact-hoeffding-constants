#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build
for stem in manuscript supplement; do
  for pass in 1 2 3; do
    (cd source && pdflatex -interaction=nonstopmode -halt-on-error -output-directory=../build "$stem.tex")
  done
done
for pass in 1 2 3; do
  (cd article && pdflatex -interaction=nonstopmode -halt-on-error combined_all.tex)
done

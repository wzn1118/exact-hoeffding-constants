# Exact Hoeffding Constants for Finite Exchangeable Sequences

Zinan Wang · 2026-10-15

The complete article is `article/combined_all.pdf` (34 pages). Its single LaTeX entry point is `article/combined_all.tex`.

The principal paper and technical supplement are also supplied separately as `manuscript.pdf` and `supplementary_refinements.pdf`. Their modular sources are in `source/`. Run `bash build_articles.sh` with pdfLaTeX to rebuild all three PDFs.

For arXiv, upload `Wang_Zinan_Exact_Hoeffding_arXiv_Source_2026-10-15.zip`, the dedicated single-entry source archive included here. `abstract.txt` and `arxiv_metadata.json` provide the submission fields.

The `refs/` catalogue covers 16 cited works and includes four unchanged CC BY 4.0 PDFs, with source and license records.

Copyright (c) 2026 Zinan Wang. All rights reserved in the original work. See LICENSE, COPYRIGHT.md and THIRD_PARTY_NOTICES.md.

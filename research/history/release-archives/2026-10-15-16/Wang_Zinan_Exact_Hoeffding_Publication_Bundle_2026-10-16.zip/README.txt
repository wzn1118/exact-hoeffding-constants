Reference companion for Zinan Wang and Xinhao Yang, Exact Hoeffding Constants for Finite Exchangeable Sequences.
The catalogue identifies all 16 cited works. Four unchanged CC BY 4.0 PDFs are included.
See THIRD_PARTY_NOTICES.md and refs/SOURCES.json for authorship, source versions, licenses and hashes.
Other references are supplied as bibliographic records and source links.
